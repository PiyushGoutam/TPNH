using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Azure.Storage.Blobs;
using ceTe.DynamicPDF;
using ceTe.DynamicPDF.Merger;
using ceTe.DynamicPDF.PageElements;
using Microsoft.Azure.Functions.Worker;
using System.Collections.Generic;

namespace NHProcessing
{
    public static class AppendNHNo
    {
        [Function("AppendNHNo")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log, ExecutionContext context)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            //string fileName = req.Headers["filename"];
            //From query string in LogicApp
            string fileName = req.Query["filename"];
            string nhNo = req.Headers["nhNo"];
            string donorNumber = req.Headers["donorNumber"];
            string tissueBank = req.Headers["tissueBank"];


            log.LogInformation("fileName  " + fileName + "  nhNo  " + nhNo);

            var config = new ConfigurationBuilder()
                                 // .SetBasePath(context.FunctionAppDirectory)
                                 .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                                 .AddEnvironmentVariables()
                                 .Build();


            if (!string.IsNullOrWhiteSpace(nhNo))
            {

                string storageAcctName = config["StorageAcctName"];
                string storageAcctKey = config["StorageAcctKey"];
                string storageAcctContainer = config["StorageAcctContainer"];
                string pdfLicenseKey = config["PdfLicenseKey"];
                string nhAppendedStorageAcctContainer = config["NHAppendedStorageAcctContainer"];
                string AzureWebJobsStorageConn = config["AzureWebJobsStorage"];

                float top = (float)Convert.ToDouble(config["Top"]);
                float right = (float)Convert.ToDouble(config["Right"]);
                float expandPageHeight = (float)Convert.ToDouble(config["ExpandPageHeight"]);

                //var storageAccount = new CloudStorageAccount(new StorageCredentials(storageAcctName, storageAcctKey), true);
                //var cloudBlobClient = storageAccount.CreateCloudBlobClient();
                //var storageContainer = cloudBlobClient.GetContainerReference(storageAcctContainer);
                //var blob = storageContainer.GetBlobReference(fileName);


                BlobServiceClient blobServiceClient = new BlobServiceClient(AzureWebJobsStorageConn);
                BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(storageAcctContainer);
                BlobClient blob = containerClient.GetBlobClient(fileName);

                using (var myBlob = new MemoryStream())
                {
                    log.LogInformation(DateTime.Now.ToString() + "Picking up the file");
                    // await blob.DownloadToStreamAsync(myBlob);
                    await blob.DownloadToAsync(myBlob);
                    PdfDocument pdfDocument = new PdfDocument(myBlob.ToArray());
                    //for (int j = 0; j <= pdfDocument.Pages.Count - 1; j++)
                    //{
                    //    PdfPage testpage = pdfDocument.Pages[j].;
                    //}
                    log.LogInformation(DateTime.Now.ToString() + "Started Tagging");
                    MergeDocument document = new MergeDocument(pdfDocument);
                    Document.AddLicense(pdfLicenseKey);

                    for (int i = 0; i <= document.Pages.Count - 1; i++)
                    {
                        Page page = document.Pages[i];
                        float angle = page.Rotate;

                        TextArea headerTextArea = new TextArea(nhNo, 0, 0, 200, 10);
                        headerTextArea.Align = TextAlign.Right;
                        headerTextArea.Font = Font.HelveticaBold;
                        headerTextArea.FontSize = 14;
                        headerTextArea.Angle = -angle;
                        headerTextArea.Height = headerTextArea.GetRequiredHeight();

                        float expandPageBy = headerTextArea.Height + expandPageHeight; // Add additional padding here or fixed amount if needed


                        if (angle == 90)
                        {
                            Dimensions edge = page.Dimensions.Edge;
                            if (edge.Left < edge.Right) edge.Left -= expandPageBy;
                            else edge.Right -= expandPageBy;
                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

                            headerTextArea.X = -page.Dimensions.LeftMargin + top;
                            headerTextArea.Y = headerTextArea.Width - page.Dimensions.TopMargin + right;
                        }
                        else if (angle == 180)
                        {
                            Dimensions edge = page.Dimensions.Edge;
                            if (edge.Top < edge.Bottom) edge.Top -= expandPageBy;
                            else edge.Bottom -= expandPageBy;
                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

                            headerTextArea.X = headerTextArea.Width - page.Dimensions.LeftMargin + right;
                            headerTextArea.Y = page.Dimensions.Height - page.Dimensions.TopMargin - top;
                        }
                        else if (angle == 270)
                        {
                            Dimensions edge = page.Dimensions.Edge;
                            if (edge.Left > edge.Right) edge.Left += expandPageBy;
                            else edge.Right += expandPageBy;
                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

                            headerTextArea.X = page.Dimensions.Width - page.Dimensions.LeftMargin - top;
                            headerTextArea.Y = page.Dimensions.Height - page.Dimensions.TopMargin - headerTextArea.Width - right;
                        }
                        else
                        {

                            Dimensions edge = page.Dimensions.Edge;
                            if (edge.Top > edge.Bottom) edge.Top += expandPageBy;
                            else edge.Bottom += expandPageBy;
                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

                            headerTextArea.X = page.Dimensions.Width - page.Dimensions.LeftMargin - headerTextArea.Width - right;
                            headerTextArea.Y = -page.Dimensions.TopMargin + top;
                        }

                        page.Elements.Add(headerTextArea);

                    }
                    log.LogInformation(DateTime.Now.ToString() + "Finished Tagging"); //updated by ~Sri

                    using (MemoryStream outputStream = new MemoryStream())
                    {

                        document.Draw(outputStream);
                        BlobContainerClient storageContainer = blobServiceClient.GetBlobContainerClient(nhAppendedStorageAcctContainer);
                        BlobClient outBlob = storageContainer.GetBlobClient(fileName);
                        //var outBlob = storageContainer.GetBlockBlobReference(fileName);
                        outputStream.Position = 0;

                        await outBlob.UploadAsync(outputStream, true);

                        Dictionary<string, string> metadata = new Dictionary<string, string> {
                                { "NHNumber", nhNo }, { "DonorNumber", "23060307" } };
                        outBlob.SetMetadata(metadata);

                        Console.WriteLine(DateTime.Now.ToString() + "Started uploading back to NHappeneded blob");
                        byte[] PdfByteData = outputStream.ToArray();
                        File.WriteAllBytes(@"C:\Temp\S11585548\" + fileName, PdfByteData);

                        //outBlob.Upload(outputStream);
                        //await outBlob.UploadFromStreamAsync(outputStream);
                        Console.WriteLine(DateTime.Now.ToString() + "finished uploading back to NHappeneded blob");

                        //document.Draw(outputStream);
                        //storageContainer = cloudBlobClient.GetContainerReference(nhAppendedStorageAcctContainer);
                        //var outBlob = storageContainer.GetBlockBlobReference(fileName);
                        //outBlob.Metadata["TissueBank"] = tissueBank;
                        //outBlob.Metadata["NHNumber"] = nhNo;
                        //outBlob.Metadata["DonorNumber"] = donorNumber;
                        //outputStream.Position = 0;
                        //log.LogInformation(DateTime.Now.ToString()+"Started uploading back to NHappeneded blob");
                        //await outBlob.UploadFromStreamAsync(outputStream);
                        //log.LogInformation(DateTime.Now.ToString() + "finished uploading back to NHappeneded blob");
                    }
                }
            }

            return string.IsNullOrWhiteSpace(nhNo) ? new OkObjectResult("0") : new OkObjectResult(nhNo);

        }
    }

}
