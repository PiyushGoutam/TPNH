//using System;
//using System.IO;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Logging;
//using Newtonsoft.Json;
//using System.Net.Http;
//using Microsoft.Azure.Functions.Worker;

//namespace NHProcessing
//{
//    public static class SentToPdfAppendQueue
//    {
//        [Function("SentToPdfAppendQueue")]
//        public static IActionResult Run(
//            [HttpTrigger(AuthorizationLevel.Function, "post")]HttpRequest req,
//            ILogger log,
//            [Queue("nhprocess", Connection = "AzureWebJobsStorage")]out ProcessRequest process)
//        {
//            string requestBody = new StreamReader(req.Body).ReadToEnd();
//            dynamic data = JsonConvert.DeserializeObject(requestBody);
//            string callbackUrl = data?.callbackUrl;

//            string fileName = req.Query["filename"]; ;
//            string donorNumber = req.Headers["donorNumber"];
//            string tissueBank = req.Headers["tissueBank"];
//            string nhNo = req.Headers["nhNo"];


//            log.LogInformation("fileName  " + fileName + "  nhNo  " + nhNo);

//            //This will drop a message in a queue that QueueTrigger will pick up
//            process = new ProcessRequest { callbackUrl = callbackUrl, FileName = fileName, DonorNumber = donorNumber, TissueBank = tissueBank, NhNo = nhNo};
//            return new AcceptedResult();
//        }

//    }

//    public class ProcessRequest
//    {
//        public string callbackUrl { get; set; }
//        public string FileName { get; set; }
//        public string DonorNumber { get; set; }
//        public string TissueBank { get; set; }
//        public string NhNo { get; set; }
//    }

//    public class ProcessResponse
//    {
//        public string NhNo { get; set; }
//    }
//}
