//using ceTe.DynamicPDF;
//using ceTe.DynamicPDF.Merger;
//using ceTe.DynamicPDF.PageElements;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Logging;
//using Microsoft.WindowsAzure.Storage;
//using Microsoft.WindowsAzure.Storage.Auth;
//using System;
//using System.IO;
//using System.Net.Http;
//using System.Threading.Tasks;
//using Microsoft.Azure.Functions.Worker;

//namespace NHProcessing
//{
//    public static class ProcessPdf
//    {
//        public static HttpClient client = new HttpClient();

//        [Function("ProcessPdf")]
//        public static async Task Run([QueueTrigger("nhprocess", Connection = "AzureWebJobsStorage")]ProcessRequest item, ILogger log, ExecutionContext context,
//            [Queue("spcopyinfo", Connection = "AzureWebJobsStorage")] IAsyncCollector<SharePointCopyInfo> process
//            )
//        {
//            string fileName = item.FileName;
//            string donorNumber = item.DonorNumber;
//            string tissueBank = item.TissueBank;
//            string nhNo = item.NhNo;

//            string filepath = @"D:\home\data\" + fileName;
//            string outfilepath = @"D:\home\data\out_" + fileName;

//            log.LogInformation("fileName  " + fileName + "  nhNo  " + nhNo);

//            var config = new ConfigurationBuilder()
//                     .SetBasePath(context.FunctionAppDirectory)
//                     .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
//                     .AddEnvironmentVariables()
//                     .Build();

//            string storageAcctName = config["StorageAcctName"];
//            string storageAcctKey = config["StorageAcctKey"];
//            string storageAcctContainer = config["StorageAcctContainer"];
//            string pdfLicenseKey = config["PdfLicenseKey"];
//            string nhAppendedStorageAcctContainer = config["NHAppendedStorageAcctContainer"];

//            try
//            {

//                if (!string.IsNullOrWhiteSpace(nhNo))
//                {

//                    float top = (float)Convert.ToDouble(config["Top"]);
//                    float right = (float)Convert.ToDouble(config["Right"]);
//                    float expandPageHeight = (float)Convert.ToDouble(config["ExpandPageHeight"]);

//                    var storageAccount = new CloudStorageAccount(new StorageCredentials(storageAcctName, storageAcctKey), true);
//                    var cloudBlobClient = storageAccount.CreateCloudBlobClient();
//                    var storageContainer = cloudBlobClient.GetContainerReference(storageAcctContainer);

//                    var blob = storageContainer.GetBlobReference(fileName);

//                    await blob.DownloadToFileAsync(filepath, FileMode.OpenOrCreate);
//                    PdfDocument pdfDocument = new PdfDocument(filepath);
//                    MergeDocument document = new MergeDocument(pdfDocument);
//                    Document.AddLicense(pdfLicenseKey);

//                    for (int i = 0; i <= document.Pages.Count - 1; i++)
//                    {
//                        Page page = document.Pages[i];
//                        float angle = page.Rotate;

//                        TextArea headerTextArea = new TextArea(nhNo, 0, 0, 200, 10);
//                        headerTextArea.Align = TextAlign.Right;
//                        headerTextArea.Font = Font.HelveticaBold;
//                        headerTextArea.FontSize = 14;
//                        headerTextArea.Angle = -angle;
//                        headerTextArea.Height = headerTextArea.GetRequiredHeight();

//                        float expandPageBy = headerTextArea.Height + expandPageHeight; // Add additional padding here or fixed amount if needed


//                        if (angle == 90)
//                        {
//                            Dimensions edge = page.Dimensions.Edge;
//                            if (edge.Left < edge.Right) edge.Left -= expandPageBy;
//                            else edge.Right -= expandPageBy;
//                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

//                            headerTextArea.X = -page.Dimensions.LeftMargin + top;
//                            headerTextArea.Y = headerTextArea.Width - page.Dimensions.TopMargin + right;
//                        }
//                        else if (angle == 180)
//                        {
//                            Dimensions edge = page.Dimensions.Edge;
//                            if (edge.Top < edge.Bottom) edge.Top -= expandPageBy;
//                            else edge.Bottom -= expandPageBy;
//                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

//                            headerTextArea.X = headerTextArea.Width - page.Dimensions.LeftMargin + right;
//                            headerTextArea.Y = page.Dimensions.Height - page.Dimensions.TopMargin - top;
//                        }
//                        else if (angle == 270)
//                        {
//                            Dimensions edge = page.Dimensions.Edge;
//                            if (edge.Left > edge.Right) edge.Left += expandPageBy;
//                            else edge.Right += expandPageBy;
//                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

//                            headerTextArea.X = page.Dimensions.Width - page.Dimensions.LeftMargin - top;
//                            headerTextArea.Y = page.Dimensions.Height - page.Dimensions.TopMargin - headerTextArea.Width - right;
//                        }
//                        else
//                        {

//                            Dimensions edge = page.Dimensions.Edge;
//                            if (edge.Top > edge.Bottom) edge.Top += expandPageBy;
//                            else edge.Bottom += expandPageBy;
//                            page.Dimensions = new ExtendedPageDimensions(edge, page.Dimensions.Body);

//                            headerTextArea.X = page.Dimensions.Width - page.Dimensions.LeftMargin - headerTextArea.Width - right;
//                            headerTextArea.Y = -page.Dimensions.TopMargin + top;
//                        }

//                        page.Elements.Add(headerTextArea);
//                    }



//                    document.Draw(outfilepath);
//                    storageContainer = cloudBlobClient.GetContainerReference(nhAppendedStorageAcctContainer);
//                    var outBlob = storageContainer.GetBlockBlobReference(fileName);
//                    outBlob.Metadata["TissueBank"] = tissueBank;
//                    outBlob.Metadata["NHNumber"] = nhNo;
//                    outBlob.Metadata["DonorNumber"] = donorNumber;
//                    await outBlob.UploadFromFileAsync(outfilepath);
//                    DeleteAllFile(filepath, outfilepath);

//                }
//            }
//            catch (Exception ex)
//            {
//                DeleteAllFile(filepath, outfilepath);
//                log.LogInformation(ex.ToString());
//                await process.AddAsync(new SharePointCopyInfo { FileName = fileName, LibraryName = tissueBank, ContainerName = storageAcctContainer, Path = "/" + tissueBank + "/" });
//                await client.PostAsJsonAsync(item.callbackUrl, "ERROR");
//                throw;
//            }


//            ProcessResponse result = new ProcessResponse { NhNo = nhNo };
//            await client.PostAsJsonAsync(item.callbackUrl, result);
//        }

//        private static void DeleteAllFile(string filepath, string outfilepath)
//        {
//            if (File.Exists(filepath))
//                File.Delete(filepath);
//            if (File.Exists(outfilepath))
//                File.Delete(outfilepath);
//        }

//        public class SharePointCopyInfo
//        {
//            public string callbackUrl { get; set; }
//            public string FileName { get; set; }
//            public string LibraryName { get; set; }
//            public string ContainerName { get; set; }
//            public string Path { get; set; }

//        }
//    }
//}
