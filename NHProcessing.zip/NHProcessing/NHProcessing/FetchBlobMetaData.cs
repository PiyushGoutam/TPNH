//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Logging;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Azure.Functions.Worker;

//namespace NHProcessing
//{
//    public static class FetchBlobMetaData
//    {
//        [Function("FetchBlobMetaData")]
//        public static async Task<IActionResult> Run(
//            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
//            ILogger log, ExecutionContext context)
//        {
//            log.LogInformation("C# HTTP trigger function processed a request.");

//            string fileName
//                = req.Query["fileName"];

//            string storageAcctContainer = req.Headers["storageAcctContainer"];

//            var config = new ConfigurationBuilder()
//                     .SetBasePath(context.FunctionAppDirectory)
//                     .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
//                     .AddEnvironmentVariables()
//                     .Build();

//            string storageAcctName = config["StorageAcctName"];
//            string storageAcctKey = config["StorageAcctKey"];
//            string storageAcctContainer = config["StorageAcctContainer"];


//            var storageAccount = new CloudStorageAccount(new StorageCredentials(storageAcctName, storageAcctKey), true);
//            var cloudBlobClient = storageAccount.CreateCloudBlobClient();
//            var storageContainer = cloudBlobClient.GetContainerReference(storageAcctContainer);

//            var blob = storageContainer.GetBlobReference(fileName);

//            await blob.FetchAttributesAsync();

//            string donorNumber = string.Empty;
//            string tissueBank = string.Empty;
//            string nhNo = string.Empty;
//            string dsUpload = string.Empty;

//            foreach (var metadataItem in blob.Metadata)
//            {
//                if (metadataItem.Key.Equals("DonorNumber"))
//                    donorNumber = metadataItem.Value;
//                else if (metadataItem.Key.Equals("TissueBank"))
//                    tissueBank = metadataItem.Value;
//                else if (metadataItem.Key.Equals("NHNumber"))
//                    nhNo = metadataItem.Value;
//                else if (metadataItem.Key.Equals("DsUpload"))
//                    dsUpload = metadataItem.Value;
//            }

//            return new OkObjectResult(donorNumber + "," + tissueBank + "," + nhNo + "," + dsUpload);
//        }
//    }
//}
